import pywhatkit

phone_number = ''
message = 'Estou testando uma programação em Python'
hours = 17
minutes = 32
pywhatkit.sendwhatmsg(phone_number, message, hours, minutes)
print('Mensagem enviada!')